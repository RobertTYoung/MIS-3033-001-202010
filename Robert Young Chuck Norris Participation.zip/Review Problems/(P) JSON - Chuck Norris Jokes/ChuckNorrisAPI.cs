﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _P__JSON___Chuck_Norris_Jokes
{
    class ChuckNorrisAPI
    {
        public string value { get; set; }

    }
    //{
    //    public List<Category> results { get; set; }
    //}
    //public class Category
    //{
    //    public string value { get; set; }

    //    //public override string ToString()
    //    //{
    //    //    return value[0].ToString().ToUpper() + value.Substring(1, value.Length - 1);
    //    //}

    //}

}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace _P__MVC___Beginner.Models
{
    public class ChuckNorrisAPI
    {
        public string icon_url { get;  set; }
        public string value { get; set; }
    }
}